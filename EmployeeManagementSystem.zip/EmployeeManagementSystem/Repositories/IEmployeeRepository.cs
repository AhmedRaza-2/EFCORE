﻿namespace EmployeeManagementSystem.Repositories
{
    public class IEmployeeRepository
    {
    }
}
