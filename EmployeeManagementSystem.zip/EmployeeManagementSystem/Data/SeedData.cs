﻿namespace EmployeeManagementSystem.Data
{
    public class SeedData
    {
    }
}
