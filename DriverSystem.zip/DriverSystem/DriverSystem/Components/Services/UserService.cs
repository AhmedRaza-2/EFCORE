﻿using DriverSystem.Components.Models;
using Microsoft.Data.SqlClient;

namespace DriverSystem.Components.Services
{
    public class UserService
    {
        private readonly string connStr;

        public UserService(IConfiguration config)
        {
            connStr = config.GetConnectionString("DefaultConnection");
        }

        public async Task<bool> Register(User user)
        {
            using var conn = new SqlConnection(connStr);
            await conn.OpenAsync();
            var cmd = new SqlCommand("INSERT INTO Users (Username, Password) VALUES (@u, @p)", conn);
            cmd.Parameters.AddWithValue("@u", user.Username);
            cmd.Parameters.AddWithValue("@p", user.Password);
            try
            {
                await cmd.ExecuteNonQueryAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> Login(User user)
        {
            using var conn = new SqlConnection(connStr);
            await conn.OpenAsync();
            var cmd = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username=@u AND Password=@p", conn);
            cmd.Parameters.AddWithValue("@u", user.Username);
            cmd.Parameters.AddWithValue("@p", user.Password);
            var count = (int)await cmd.ExecuteScalarAsync();
            return count > 0;
        }
    }
}
