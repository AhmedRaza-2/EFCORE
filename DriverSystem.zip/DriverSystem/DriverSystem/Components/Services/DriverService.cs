﻿using Microsoft.Data.SqlClient;
using DriverSystem.Components.Models;

namespace DriverSystem.Components.Services
{
    public class DriverService
    {
        private readonly string _connectionString;

        public DriverService(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<List<Driver>> GetAllDriversAsync()
        {
            var drivers = new List<Driver>();
            using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            var cmd = new SqlCommand("SELECT * FROM Driver", conn);
            var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                drivers.Add(new Driver
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    PhoneNumber = reader.GetString(2),
                    LicenseNumber = reader.GetString(3),
                    Vehicle = reader.GetString(4)
                });
            }

            return drivers;
        }

        public async Task AddDriverAsync(Driver driver)
        {
            using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            var cmd = new SqlCommand("INSERT INTO Driver (Name, PhoneNumber, LicenseNumber, Vehicle) VALUES (@Name, @Phone, @License, @Vehicle)", conn);
            cmd.Parameters.AddWithValue("@Name", driver.Name);
            cmd.Parameters.AddWithValue("@Phone", driver.PhoneNumber);
            cmd.Parameters.AddWithValue("@License", driver.LicenseNumber);
            cmd.Parameters.AddWithValue("@Vehicle", driver.Vehicle);

            await cmd.ExecuteNonQueryAsync();
        }

        public async Task UpdateDriverAsync(Driver driver)
        {
            using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            var cmd = new SqlCommand("UPDATE Driver SET Name=@Name, PhoneNumber=@Phone, LicenseNumber=@License, Vehicle=@Vehicle WHERE Id=@Id", conn);
            cmd.Parameters.AddWithValue("@Id", driver.Id);
            cmd.Parameters.AddWithValue("@Name", driver.Name);
            cmd.Parameters.AddWithValue("@Phone", driver.PhoneNumber);
            cmd.Parameters.AddWithValue("@License", driver.LicenseNumber);
            cmd.Parameters.AddWithValue("@Vehicle", driver.Vehicle);

            await cmd.ExecuteNonQueryAsync();
        }

        public async Task DeleteDriverAsync(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            await conn.OpenAsync();

            var cmd = new SqlCommand("DELETE FROM Driver WHERE Id = @Id", conn);
            cmd.Parameters.AddWithValue("@Id", id);

            await cmd.ExecuteNonQueryAsync();
        }
    }
}

