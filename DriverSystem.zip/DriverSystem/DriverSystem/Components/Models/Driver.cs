﻿namespace DriverSystem.Components.Models
{
    public class Driver
    {

        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string PhoneNumber { get; set; }= string.Empty;
        public string LicenseNumber { get; set; }= string.Empty;
        public string Vehicle { get; set; } = string.Empty;
    }
}

