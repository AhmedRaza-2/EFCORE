using Microsoft.Data.SqlClient;
using System;
using Week_10_Ado.net_Emp_sys.Models;
using Microsoft.Extensions.Configuration;

namespace Week_10_Ado.net_Emp_sys.Services
{
    public class EmployeeService
    {
        private readonly string? connectionString;

        public EmployeeService(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<EmployeeModel> GetEmployees()
        {
            var employees = new List<EmployeeModel>();
            try
            {
                using SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM Employees", conn);
                using SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    // Use a safer approach to handle date values
                    DateTime hireDate;
                    if (!DateTime.TryParse(reader["HireDate"].ToString(), out hireDate) || 
                        hireDate < new DateTime(1753, 1, 1) || 
                        hireDate > new DateTime(9999, 12, 31))
                    {
                        hireDate = DateTime.Now;
                    }

                    employees.Add(new EmployeeModel
                    {
                        Id = (int)reader["Id"],
                        Name = reader["Name"]?.ToString(),
                        Email = reader["Email"]?.ToString(),
                        Department = reader["Department"]?.ToString(),
                        HireDate = hireDate
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching employees: {ex.Message}");
                // You could throw the exception or handle it differently
                // For now, we'll return an empty list if there's an error
            }
            return employees;
        }

        public void AddEmployee(EmployeeModel emp)
        {
            try
            {
                // Validate hire date to ensure it's within SQL Server's datetime range
                if (emp.HireDate < new DateTime(1753, 1, 1) || emp.HireDate > new DateTime(9999, 12, 31))
                {
                    emp.HireDate = DateTime.Now;
                }

                using SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Employees (Name, Email, Department, HireDate) VALUES (@Name, @Email, @Department, @HireDate)", conn);
                cmd.Parameters.AddWithValue("@Name", emp.Name ?? string.Empty);
                cmd.Parameters.AddWithValue("@Email", emp.Email ?? string.Empty);
                cmd.Parameters.AddWithValue("@Department", emp.Department ?? string.Empty);
                cmd.Parameters.AddWithValue("@HireDate", emp.HireDate);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Log the error and re-throw
                Console.WriteLine($"Error adding employee: {ex.Message}");
                throw;
            }
        }

        public void UpdateEmployee(EmployeeModel emp)
        {
            try
            {
                // Validate hire date to ensure it's within SQL Server's datetime range
                if (emp.HireDate < new DateTime(1753, 1, 1) || emp.HireDate > new DateTime(9999, 12, 31))
                {
                    emp.HireDate = DateTime.Now;
                }

                using SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                SqlCommand cmd = new SqlCommand("UPDATE Employees SET Name=@Name, Email=@Email, Department=@Department, HireDate=@HireDate WHERE Id=@Id", conn);
                cmd.Parameters.AddWithValue("@Id", emp.Id);
                cmd.Parameters.AddWithValue("@Name", emp.Name ?? string.Empty);
                cmd.Parameters.AddWithValue("@Email", emp.Email ?? string.Empty);
                cmd.Parameters.AddWithValue("@Department", emp.Department ?? string.Empty);
                cmd.Parameters.AddWithValue("@HireDate", emp.HireDate);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Log the error and re-throw
                Console.WriteLine($"Error updating employee: {ex.Message}");
                throw;
            }
        }

        public void DeleteEmployee(int id)
        {
            try
            {
                using SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                SqlCommand cmd = new SqlCommand("DELETE FROM Employees WHERE Id=@Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Log the error and re-throw
                Console.WriteLine($"Error deleting employee: {ex.Message}");
                throw;
            }
        }
    }
}
