namespace Week_10_Ado.net_Emp_sys.Models
{
    public class EmployeeModel
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Department { get; set; }
        public DateTime HireDate { get; set; } = DateTime.Now;

        public EmployeeModel()
        {
            // Setting a default hire date to avoid SQL Server datetime range issues
            if (HireDate == default)
            {
                HireDate = DateTime.Now;
            }
        }
    }
}
