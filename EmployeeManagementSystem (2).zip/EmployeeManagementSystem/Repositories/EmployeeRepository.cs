﻿namespace EmployeeManagementSystem.Repositories
{
    public class EmployeeRepository
    {
    }
}
